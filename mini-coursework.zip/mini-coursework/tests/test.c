#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "perimeter.h"

void runTests(int n, ull expr)
{
    ull act = perimeter(n);
    printf("For numbers: %d Expected: %llu Got: %llu\n", n, expr, act);
    if(act != expr)
        printf("Expected %llu, got %llu\n", expr, act);
    assert(act == expr);
}

/*
 The sequence of the difference of two adjacent perimeters is particularly the Fibonacci sequence.
 */

/*
 Therefore, you can add one more check to determine whether the function is correct by calling the function multiple times to obtain adjacent larger results of the given number n, and check whether their difference is a Fibonacci sequence.
*/

/*
 This time by simply assigning the correct value to a particular input is not feasible.
*/
void runTestsPlus(int n){
    ull result = perimeter(n);
    ull result_pls_2 = perimeter(n + 2);
    ull result_pls_3 = perimeter(n + 3);
    if (result_pls_3 - result_pls_2 == result_pls_2 - result) {
        printf("Good job!\n");
    }
    else printf("Wrong answer!\n");
    assert(result_pls_3 - result_pls_2 == result_pls_2 - result);
}

int main() {
    runTests(5, 80);
    runTestsPlus(5);
    runTests(7, 216);
    runTestsPlus(7);
    runTests(20, 114624);
    runTestsPlus(20);
    runTests(30, 14098308);
    runTestsPlus(30);
    return 0;
}

