typedef unsigned long long ull;

ull perimeter(int n);
