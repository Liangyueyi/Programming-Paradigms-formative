#include "perimeter.h"

ull perimeter(int n) {
    int result = 4;
    int now = 1;
    int last = 1;
    for (int i = 2; i < n + 2; i++) {
        result += 4 * now;
        now += last;
        last = now - last;
    }
    return result;
}

